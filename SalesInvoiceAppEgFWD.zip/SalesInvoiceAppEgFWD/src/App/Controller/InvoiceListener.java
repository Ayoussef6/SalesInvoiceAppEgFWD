
package App.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import App.Model.HeaderTable;
import App.Model.InvoiceModel;
import App.Model.LineModel;
import App.Model.LineTable;
import App.View.HeaderDialog;
import App.View.LineDialog;
import App.View.InvoiceGUIFrame;

public class InvoiceListener implements ActionListener, ListSelectionListener {

    private InvoiceGUIFrame UIFrame;
    private HeaderDialog headerD;
    private LineDialog lineD;

    public InvoiceListener(InvoiceGUIFrame UIFrame) {
        this.UIFrame = UIFrame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("ActionListener");

        String command = e.getActionCommand();
        switch (command) {
            case "New Invoice":
                addNewInvoice();
                break;
            case "Delete Invoice":
                deleteInv();
                break;
            case "New Line":
                addNewLine();
                break;
            case "Delete Line":
                deleteLineFromItemTable();
                break;
            case "Load Files":
                loadFiles(null, null);
                break;
            case "Save Data":
                saveInvoiceData();
                break;
            case "newInvoiceOK":
                newInvoiceOK();
                break;
            case "newInvoiceCancel":
                cancelNewInvoice();
                break;
            case "newLineOK":
                clickOkOnNewLine();
                break;
            case "newLineCancel":
                cancelNewLine();
                break;
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        System.out.println("ListSelectionListener");

        int row = UIFrame.getInvoicesTable().getSelectedRow();
        System.out.println("Selected Row: " + row);
        if (row > -1 && row < UIFrame.getInvoices().size()) {
            InvoiceModel inv = UIFrame.getInvoices().get(row);
            UIFrame.getCustNameLabel().setText(inv.getCustomerName());
            UIFrame.getInvDateLabel().setText(UIFrame.sdf.format(inv.getInvDate()));
            UIFrame.getInvNumLabel().setText("" + inv.getNum());
            UIFrame.getInvTotalLabel().setText("" + inv.getTotalAmount());

            List<LineModel> lines = inv.getTableLines();
            UIFrame.getLinesTable().setModel(new LineTable(lines));
        } else {
            UIFrame.getCustNameLabel().setText("");
            UIFrame.getInvDateLabel().setText("");
            UIFrame.getInvNumLabel().setText("");
            UIFrame.getInvTotalLabel().setText("");

            UIFrame.getLinesTable().setModel(new LineTable(new ArrayList<LineModel>()));
        }

    }

    private void addNewInvoice() {
        headerD = new HeaderDialog(UIFrame);
        headerD.setVisible(true);
    }

    private void deleteInv() {
        int row = UIFrame.getInvoicesTable().getSelectedRow();
        if (row != -1) {
            UIFrame.getInvoices().remove(row);
            ((HeaderTable) UIFrame.getInvoicesTable().getModel()).fireTableDataChanged();
        }
    }

    private void addNewLine() {
        int selectedInv = UIFrame.getInvoicesTable().getSelectedRow();
        if (selectedInv != -1) {
            lineD = new LineDialog(UIFrame);
            lineD.setVisible(true);
        }
    }

    private void deleteLineFromItemTable() {
        int row = UIFrame.getLinesTable().getSelectedRow();
        if (row != -1) {
            int headerRow = UIFrame.getInvoicesTable().getSelectedRow();
            LineTable lineTableModel = (LineTable) UIFrame.getLinesTable().getModel();
            lineTableModel.getLines().remove(row);
            lineTableModel.fireTableDataChanged();
            ((HeaderTable) UIFrame.getInvoicesTable().getModel()).fireTableDataChanged();
            UIFrame.getInvoicesTable().setRowSelectionInterval(headerRow, headerRow);
        }
    }

    public void loadFiles(String headrPath, String linePath) {
        File headerFile = null;
        File lineFile = null;
        if (headrPath == null && linePath == null) {
            JFileChooser fc = new JFileChooser();
            int result = fc.showOpenDialog(UIFrame);
            if (result == JFileChooser.APPROVE_OPTION) {
                headerFile = fc.getSelectedFile();
                result = fc.showOpenDialog(UIFrame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    lineFile = fc.getSelectedFile();
                }
            }
        } else {
            headerFile = new File(headrPath);
            lineFile = new File(linePath);
        }

        if (headerFile != null && lineFile != null) {
            try {
               
                List<String> headerLines = Files.lines(Paths.get(headerFile.getAbsolutePath())).collect(Collectors.toList());
               
                List<String> lineLines = Files.lines(Paths.get(lineFile.getAbsolutePath())).collect(Collectors.toList());
                UIFrame.getInvoices().clear();
                for (String headerLine : headerLines) {
                    String[] parts = headerLine.split(",");                      String numberString = parts[0];
                    String InvoiceDateString = parts[1];
                    String name = parts[2];
                    int number = Integer.parseInt(numberString);
                    Date InvoiceDate = InvoiceGUIFrame.sdf.parse(InvoiceDateString);
                    InvoiceModel inv = new InvoiceModel(number, name, InvoiceDate);
                    UIFrame.getInvoices().add(inv);
                }
                System.out.println("Check point");
                for (String lineLine : lineLines) {
                    String[] parts = lineLine.split(",");
                   
                    int number = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    double priceAmount = Double.parseDouble(parts[2]);
                    int countNumber = Integer.parseInt(parts[3]);
                    InvoiceModel inv = getInvoiceByNum(number);
                    LineModel line = new LineModel(name, priceAmount, countNumber, inv);
                    inv.getTableLines().add(line);
                }
                System.out.println("Check point");
                UIFrame.getInvoicesTable().setModel(new HeaderTable(UIFrame.getInvoices()));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private InvoiceModel getInvoiceByNum(int number) {
        for (InvoiceModel inv : UIFrame.getInvoices()) {
            if (number == inv.getNum()) {
                return inv;
            }
        }
        return null;
    }

    private void saveInvoiceData() {
        String invoiceDetailssData = "";
        String linesData = "";
        for (InvoiceModel invoiceDetails : UIFrame.getInvoices()) {
            invoiceDetailssData += invoiceDetails.toCSV();
            invoiceDetailssData += "\n";
            for (LineModel line : invoiceDetails.getTableLines()) {
                linesData += line.converttoCSV();
                linesData += "\n";
            }
        }

        JFileChooser fc = new JFileChooser();
        int result = fc.showSaveDialog(UIFrame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File headerFile = fc.getSelectedFile();
            result = fc.showSaveDialog(UIFrame);
            if (result == JFileChooser.APPROVE_OPTION) {
                File lineFile = fc.getSelectedFile();
                try {
                    FileWriter headerFW = new FileWriter(headerFile);
                    headerFW.write(invoiceDetailssData);
                    headerFW.flush();
                    headerFW.close();

                    FileWriter lineFW = new FileWriter(lineFile);
                    lineFW.write(linesData);
                    lineFW.flush();
                    lineFW.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(UIFrame, "Error while saving data", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void newInvoiceOK() {
        String customerName = headerD.getCustNameField().getText();
        String InvoiceDate = headerD.getInvDateField().getText();
        headerD.setVisible(false);
        headerD.dispose();
        int number = getNextInvoiceNum();
        try {
            Date invDate = UIFrame.sdf.parse(InvoiceDate);
            InvoiceModel inv = new InvoiceModel(number, customerName, invDate);
            UIFrame.getInvoices().add(inv);
            ((HeaderTable) UIFrame.getInvoicesTable().getModel()).fireTableDataChanged();
        } catch (ParseException pex) {
            JOptionPane.showMessageDialog(UIFrame, "Error in InvoiceDate format", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getNextInvoiceNum() {
        int number = 1;
        for (InvoiceModel inv : UIFrame.getInvoices()) {
            if (inv.getNum() > number) {
                number = inv.getNum();
            }
        }
        return number + 1;
    }

    private void cancelNewInvoice() {
        headerD.setVisible(false);
        headerD.dispose();
    }

    private void clickOkOnNewLine() {
        int selectedInv = UIFrame.getInvoicesTable().getSelectedRow();
        if (selectedInv != -1) {
            InvoiceModel inv = UIFrame.getInvoices().get(selectedInv);
            String name = lineD.getItemNameField().getText();
            String priceAmountStr = lineD.getItemPriceField().getText();
            String countNumberStr = lineD.getItemCountField().getText();
            lineD.setVisible(false);
            lineD.dispose();
            double priceAmount = Double.parseDouble(priceAmountStr);
            int countNumber = Integer.parseInt(countNumberStr);
            LineModel line = new LineModel(name, priceAmount, countNumber, inv);
            inv.getTableLines().add(line);
            ((LineTable) UIFrame.getLinesTable().getModel()).fireTableDataChanged();
            ((HeaderTable) UIFrame.getInvoicesTable().getModel()).fireTableDataChanged();
            UIFrame.getInvoicesTable().setRowSelectionInterval(selectedInv, selectedInv);
        }
    }

    private void cancelNewLine() {
        lineD.setVisible(false);
        lineD.dispose();
    }

}
