
package App.Model;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import App.View.InvoiceGUIFrame;


public class HeaderTable extends AbstractTableModel {
    private String[] coulmns = {"Num", "Customer", 
        "Date", "Total"};
    private List<InvoiceModel> invoices;
    
    public HeaderTable(List<InvoiceModel> invoices) {
        this.invoices = invoices;
    }
    
    @Override
    public int getRowCount() {
        return invoices.size();
    }

    @Override
    public int getColumnCount() {
        return coulmns.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return coulmns[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceModel inv = invoices.get(rowIndex);
        switch (columnIndex) {
            case 0: return inv.getNum();
            case 1: return inv.getCustomerName();
            case 2: return InvoiceGUIFrame.sdf.format(inv.getInvDate());
            case 3: return inv.getTotalAmount();
        }
        return "";
    }
    
}
