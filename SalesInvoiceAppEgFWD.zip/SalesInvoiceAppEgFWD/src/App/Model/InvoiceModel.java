
package App.Model;

import java.util.Date;
import java.util.ArrayList;
import App.View.InvoiceGUIFrame;


public class InvoiceModel {
    private int number;
    private String customerName;
    private Date InvoiceDate;
    private ArrayList<LineModel> Tablelines;

    public InvoiceModel(int number, String customerName, Date InvoiceDate) {
        this.number = number;
        this.customerName = customerName;
        this.InvoiceDate = InvoiceDate;
    }
    
    public String toCSV() {
        return number + "," + InvoiceGUIFrame.sdf.format(InvoiceDate) + "," + customerName;
    }
    
    public int getNum() {
        return number;
    }

    public void setNum(int number) {
        this.number = number;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerNae(String customerName) {
        this.customerName = customerName;
    }

    public Date getInvDate() {
        return InvoiceDate;
    }

    public void setDate(Date InvoiceDate) {
        this.InvoiceDate = InvoiceDate;
    }

    public ArrayList<LineModel> getTableLines() {
        if (Tablelines == null) {
            Tablelines = new ArrayList<>();
        }
        return Tablelines;
    }

    public void setTableLines(ArrayList<LineModel> Tablelines) {
        this.Tablelines = Tablelines;
    }
    
    public double getTotalAmount() {
        double total = 0.0;
        for (LineModel line : getTableLines()) {
            total += line.getTotalPrice();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Invoice{" + "number=" + number + ", customerName=" + customerName + ", InvoiceDate=" + InvoiceDate + '}';
    }
    
    
    
}
