
package App.Model;


public class LineModel {
    private String items;
    private double priceAmount;
    private int countNumber;
    private InvoiceModel invoiceDetails;

    public LineModel(String items, double priceAmount, int countNumber, InvoiceModel invoiceDetails) {
        this.items = items;
        this.priceAmount = priceAmount;
        this.countNumber = countNumber;
        this.invoiceDetails = invoiceDetails;
    }

    public String converttoCSV() {
        return invoiceDetails.getNum() + "," + items + "," + priceAmount + "," + countNumber;
    }
    
    public String getItem() {
        return items;
    }

    public void setItem(String items) {
        this.items = items;
    }

    public double getPriceAmount() {
        return priceAmount;
    }

    public void setPriceAmount(double priceAmount) {
        this.priceAmount = priceAmount;
    }

    public int getCountNumber() {
        return countNumber;
    }

    public void setCountNumber(int countNumber) {
        this.countNumber = countNumber;
    }

    public InvoiceModel getInvoice() {
        return invoiceDetails;
    }

    public void setInvoice(InvoiceModel invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }
    
    public double getTotalPrice() {
        return getCountNumber() * getPriceAmount();
    }

    @Override
    public String toString() {
        return "Line{" + "items=" + items + ", priceAmount=" + priceAmount + ", countNumber=" + countNumber + '}';
    }
    
}
