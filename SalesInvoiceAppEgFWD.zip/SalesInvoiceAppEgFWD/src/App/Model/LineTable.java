
package App.Model;

import java.util.List;
import javax.swing.table.AbstractTableModel;


public class LineTable extends AbstractTableModel {

    private String[] coulumns = {"Item", "Unit Price", "Count", "Total"};
    private List<LineModel> Tablelines;

    public LineTable(List<LineModel> Tablelines) {
        this.Tablelines = Tablelines;
    }

    public List<LineModel> getLines() {
        return Tablelines;
    }
    
    @Override
    public int getRowCount() {
        return Tablelines.size();
    }

    @Override
    public int getColumnCount() {
        return coulumns.length;
    }

    @Override
    public String getColumnName(int column) {
        return coulumns[column];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        LineModel line = Tablelines.get(rowIndex);
        
        switch (columnIndex) {
            case 0: return line.getItem();
            case 1: return line.getPriceAmount();
            case 2: return line.getCountNumber();
            case 3: return line.getTotalPrice();
        }
        return "";
    }
    
}
