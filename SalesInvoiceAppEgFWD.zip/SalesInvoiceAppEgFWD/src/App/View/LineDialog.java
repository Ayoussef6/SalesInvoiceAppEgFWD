
package App.View;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class LineDialog extends JDialog{
    private JTextField nameField;
    private JTextField countField;
    private JTextField priceField;
    private JLabel nameLabel;
    private JLabel countLabel;
    private JLabel priceLabel;
    private JButton okButton;
    private JButton cancelButton;
    
    public LineDialog(InvoiceGUIFrame UIFrame) {
        nameField = new JTextField(20);
        nameLabel = new JLabel("Item Name");
        
        countField = new JTextField(20);
        countLabel = new JLabel("Item Count");
        
        priceField = new JTextField(20);
        priceLabel = new JLabel("Item Price");
        
        okButton = new JButton("OK");
        cancelButton = new JButton("Cancel");
        
        okButton.setActionCommand("newLineOK");
        cancelButton.setActionCommand("newLineCancel");
        
        okButton.addActionListener(UIFrame.getListener());
        cancelButton.addActionListener(UIFrame.getListener());
        setLayout(new GridLayout(4, 2));
        
        add(nameLabel);
        add(nameField);
        add(countLabel);
        add(countField);
        add(priceLabel);
        add(priceField);
        add(okButton);
        add(cancelButton);
        setModal(true);
        pack();
    }

    public JTextField getItemNameField() {
        return nameField;
    }

    public JTextField getItemCountField() {
        return countField;
    }

    public JTextField getItemPriceField() {
        return priceField;
    }
}
